
package net.mcreator.inspiritcraftreborn.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import net.mcreator.inspiritcraftreborn.block.BlockKindleleaves;
import net.mcreator.inspiritcraftreborn.ElementsInspiritCraftReborn;

@ElementsInspiritCraftReborn.ModElement.Tag
public class OreDictTreeLeaves extends ElementsInspiritCraftReborn.ModElement {
	public OreDictTreeLeaves(ElementsInspiritCraftReborn instance) {
		super(instance, 36);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("treeLeaves", new ItemStack(BlockKindleleaves.block, (int) (1)));
	}
}
