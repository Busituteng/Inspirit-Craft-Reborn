
package net.mcreator.inspiritcraftreborn.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import net.mcreator.inspiritcraftreborn.item.ItemSulfur;
import net.mcreator.inspiritcraftreborn.ElementsInspiritCraftReborn;

@ElementsInspiritCraftReborn.ModElement.Tag
public class OreDictDustsulfur extends ElementsInspiritCraftReborn.ModElement {
	public OreDictDustsulfur(ElementsInspiritCraftReborn instance) {
		super(instance, 30);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("dustSulfur", new ItemStack(ItemSulfur.block, (int) (1)));
	}
}
