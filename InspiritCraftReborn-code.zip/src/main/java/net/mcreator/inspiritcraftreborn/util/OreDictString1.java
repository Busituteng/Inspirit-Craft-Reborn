
package net.mcreator.inspiritcraftreborn.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import net.mcreator.inspiritcraftreborn.item.ItemFiber;
import net.mcreator.inspiritcraftreborn.ElementsInspiritCraftReborn;

@ElementsInspiritCraftReborn.ModElement.Tag
public class OreDictString1 extends ElementsInspiritCraftReborn.ModElement {
	public OreDictString1(ElementsInspiritCraftReborn instance) {
		super(instance, 31);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("string", new ItemStack(ItemFiber.block, (int) (1)));
	}
}
