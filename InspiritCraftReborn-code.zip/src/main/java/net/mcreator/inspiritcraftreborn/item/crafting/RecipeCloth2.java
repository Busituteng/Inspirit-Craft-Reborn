
package net.mcreator.inspiritcraftreborn.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;

import net.mcreator.inspiritcraftreborn.item.ItemCloth;
import net.mcreator.inspiritcraftreborn.ElementsInspiritCraftReborn;

@ElementsInspiritCraftReborn.ModElement.Tag
public class RecipeCloth2 extends ElementsInspiritCraftReborn.ModElement {
	public RecipeCloth2(ElementsInspiritCraftReborn instance) {
		super(instance, 11);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(ItemCloth.block, (int) (1)), new ItemStack(Items.LEATHER, (int) (1)), 1F);
	}
}
